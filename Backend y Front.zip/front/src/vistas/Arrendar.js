import React, { useState,useEffect} from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import { useForm } from 'react-hook-form';
import axios from 'axios';
import MaterialDatatable from "material-datatable";

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(3),
  },
  submit: {
    margin: theme.spacing(3, 0, 2)
  
  },
  delete : {
    backgroundColor:"red"
  }

}));

export default function Usuario() {
  const classes = useStyles();

  const timestamp = Date.now();    

  const { register, handleSubmit, errors,getValues,setValue,reset } = useForm(
  
    {defaultValues:{fecha: new Intl.DateTimeFormat('en-US', {year: 'numeric', month: '2-digit',day: '2-digit'}).format(timestamp)}}
  );

  const [accion,setAccion]= useState("Arrendar")
  const [idUsuario,setIdUsuario] = useState(null);
  const[usuarios, setUsuarios] = useState([])
  const[libro, setLibro] = useState([]) 
  const[prestamo, setPrestamo] = useState([]) 
  useEffect(() => {
    cargarUsuario();
    cargarLibro();
    cargarPrestamo();
  }, []);



  const seleccionar = (item) =>{
    setValue("libro",item._id)
 //   setValue("autor",item.autor)
  }

  const seleccionar2 = (item) =>{
//    setValue("mail",item.mail)
    setValue("idpersona",item._id)
  }

  const columns = [
    {
      name: "Seleccionar",
      options: {
        headerNoWrap: true,
        customBodyRender: (item, tablemeta, update) => {
          return (
            <Button
              variant="contained"
              className="btn-block"
              onClick={() => seleccionar(item)}
            >
              Seleccionar
            </Button>
          );
        },
      },
    },
    {
      name: 'Titulo',
      field: 'nombre'
    },
    {
      name: 'Autor',
      field: 'autor'
    }
   
  ];

  const columns2 = [
    {
      name: "Seleccionar",
      options: {
        headerNoWrap: true,
        customBodyRender: (item, tablemeta, update) => {
          return (
            <Button
              variant="contained"
              className="btn-block"
              onClick={() => seleccionar2(item)}
            >
              Seleccionar
            </Button>
          );
        },
      },
    },
    {
      name: 'Correo Electronico',
      field: 'mail'
    },
    {
      name: 'ID Usuario',
      field: '_id',
      options: {
        width: 300
        }
    }
   
  ];

  
  const options={
    selectableRows: false,
    print: false,
    onlyOneRowCanBeSelected: false,
    textLabels: {
      body: {
        noMatch: "Lo sentimos, no se encuentran registros",
        toolTip: "Sort",
      },
      pagination: {
        next: "Siguiente",
        previous: "Página Anterior",
        rowsPerPage: "Filas por página:",
        displayRows: "de",
      },
    },
    download: false,
    pagination: true,
    rowsPerPage: 5,
    usePaperPlaceholder: true,
    rowsPerPageOptions: [5, 10, 25],
    sortColumnDirection: "desc",
  }
  const onSubmit = data => {

    if(accion=="Arrendar"){
      alert("Entré aquí")
      alert(data.libro)
      axios
      .post("http://localhost:9000/api/prestamo",data)
      .then(
        (response) => {
          if (response.status == 200) {
            alert("Registro ok")
          //  cargarPrestamo();
            reset();
          }
        },
        (error) => {
          // Swal.fire(
          //   "Error",
          //   "No es posible realizar esta acción: " + error.message,
          //   "error"
          // );
        }
      )
      .catch((error) => {
        // Swal.fire(
        //   "Error",
        //   "No cuenta con los permisos suficientes para realizar esta acción",
        //   "error"
        // );
        console.log(error);
      });
    }

  }

  const cargarUsuario = async () => {

    const { data } = await axios.get("http://localhost:9000/api/usuario");
    setUsuarios(data.data);

  };


  const cargarLibro = async () => {

    const { data } = await axios.get("http://localhost:9000/api/libro");
    setLibro(data.libroConAutor);

  }; 
  
  const cargarPrestamo = async () => {

    const { data } = await axios.get("http://localhost:9000/api/prestamo");
    setPrestamo(data.data);

  }; 

  return (
    <Container component="main" maxWidth="xl">
      <CssBaseline />
      <div className={classes.paper}>

      <Typography component="h1" variant="h5">
          SELECCIONAR USUARIO Y LIBRO A ARRENDAR
      </Typography>
      <br></br>

      <Grid container spacing={1}>

            <Grid item xs={12} sm={6}>
                <MaterialDatatable               
                    title={"Usuarios"}
                    data={usuarios}
                    columns={columns2}
                    options={options}              
                />
            </Grid>

            <Grid item xs={12} sm={6}>
                <MaterialDatatable
                    title={"Libros"}
                    data={libro}
                    columns={columns}
                    options={options}              
                />
            </Grid>

      </Grid>

        <form className={classes.form} onSubmit={handleSubmit(onSubmit)}>

          <Grid container spacing={2}>

          <Grid item xs={12} sm={6}>
                ID USUARIO
              <TextField
                variant="outlined"
                required
                fullWidth
                id="idpersona"
                name="idpersona"
                autoComplete="lname"
                defaultValue=""
                InputProps={{
                    readOnly: true,
                }}
                inputRef={register}
              />
            </Grid>

            <Grid item xs={12} sm={6}>
                ID LIBRO
              <TextField             
                autoComplete="fname"
                name="libro"
                variant="outlined"
                required
                fullWidth
                id="libro"
                defaultValue=""
                InputProps={{
                    readOnly: true,
                }}
                inputRef={register}
              />
            </Grid>


            
          </Grid>
          <br></br>    


        Fecha    
          <TextField
                variant="outlined"
                required
                fullWidth
                id="fecha"
                name="fecha"
                autoComplete="lname"
                defaultValue=""
                InputProps={{
                    readOnly: true,
                }}
                inputRef={register}
          />      

          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
          >
            {accion}
          </Button>

        </form>


      </div>

    </Container>
  );
}