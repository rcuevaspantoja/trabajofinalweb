

function Componente1() {
  return (
    <div className="App">
        <h1>YO SOY EL COMPONENTE 1 </h1>
    </div>
  );
}

export default Componente1;
